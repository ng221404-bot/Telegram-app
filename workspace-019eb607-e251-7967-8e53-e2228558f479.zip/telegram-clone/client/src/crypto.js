// Custom End-to-End Encryption Protocol
// Combines AES-GCM for message encryption with ECDH key exchange

class E2ECrypto {
  constructor() {
    this.keyStore = new Map(); // conversationId -> shared key
    this.identityKeys = new Map(); // userId -> public key
    this.sessionKeyPairs = new Map(); // conversationId -> {privateKey, publicKey}
  }

  // Generate an identity key pair for the user
  async generateIdentityKeys(userId) {
    const keyPair = await window.crypto.subtle.generateKey(
      {
        name: "ECDH",
        namedCurve: "P-256"
      },
      true,
      ["deriveKey", "deriveBits"]
    );

    const publicKey = await window.crypto.subtle.exportKey("raw", keyPair.publicKey);
    this.identityKeys.set(userId, publicKey);

    return { keyPair, publicKey };
  }

  // Import another user's public key
  async importPublicKey(keyData) {
    return await window.crypto.subtle.importKey(
      "raw",
      keyData,
      {
        name: "ECDH",
        namedCurve: "P-256"
      },
      true,
      []
    );
  }

  // Generate a session key pair for a conversation
  async generateSessionKeys(conversationId) {
    const keyPair = await window.crypto.subtle.generateKey(
      {
        name: "ECDH",
        namedCurve: "P-256"
      },
      true,
      ["deriveKey", "deriveBits"]
    );

    this.sessionKeyPairs.set(conversationId, keyPair);
    const publicKey = await window.crypto.subtle.exportKey("raw", keyPair.publicKey);
    return publicKey;
  }

  // Derive a shared secret using ECDH
  async deriveSharedSecret(conversationId, peerPublicKey) {
    const sessionKeyPair = this.sessionKeyPairs.get(conversationId);
    if (!sessionKeyPair) {
      throw new Error("No session key pair found for conversation");
    }

    const importedPeerKey = await this.importPublicKey(peerPublicKey);
    const sharedSecret = await window.crypto.subtle.deriveBits(
      {
        name: "ECDH",
        public: importedPeerKey
      },
      sessionKeyPair.privateKey,
      256
    );

    // Convert shared secret to AES-GCM key
    const aesKey = await window.crypto.subtle.importKey(
      "raw",
      sharedSecret,
      {
        name: "AES-GCM"
      },
      false,
      ["encrypt", "decrypt"]
    );

    this.keyStore.set(conversationId, aesKey);
    return aesKey;
  }

  // Encrypt a message with AES-GCM
  async encryptMessage(conversationId, plaintext) {
    const key = this.keyStore.get(conversationId);
    if (!key) {
      throw new Error("No encryption key for conversation");
    }

    const encoder = new TextEncoder();
    const iv = window.crypto.getRandomValues(new Uint8Array(12));
    const encrypted = await window.crypto.subtle.encrypt(
      {
        name: "AES-GCM",
        iv: iv
      },
      key,
      encoder.encode(plaintext)
    );

    // Combine IV and encrypted data
    const result = new Uint8Array(iv.length + encrypted.byteLength);
    result.set(iv);
    result.set(new Uint8Array(encrypted), iv.length);

    return result;
  }

  // Decrypt a message with AES-GCM
  async decryptMessage(conversationId, encryptedData) {
    const key = this.keyStore.get(conversationId);
    if (!key) {
      throw new Error("No decryption key for conversation");
    }

    // Extract IV from the beginning
    const iv = encryptedData.slice(0, 12);
    const data = encryptedData.slice(12);

    const decrypted = await window.crypto.subtle.decrypt(
      {
        name: "AES-GCM",
        iv: iv
      },
      key,
      data
    );

    const decoder = new TextDecoder();
    return decoder.decode(decrypted);
  }

  // Hash a password for storage/transmission
  async hashPassword(password) {
    const encoder = new TextEncoder();
    const data = encoder.encode(password);
    const hashBuffer = await window.crypto.subtle.digest("SHA-256", data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  }

  // Generate a conversation ID from two user IDs
  generateConversationId(userId1, userId2) {
    const sorted = [userId1, userId2].sort();
    return `${sorted[0]}-${sorted[1]}`;
  }

  // Export public key as base64
  static async exportPublicKeyBase64(keyData) {
    const bytes = new Uint8Array(keyData);
    return btoa(String.fromCharCode(...bytes));
  }

  // Import public key from base64
  static async importPublicKeyBase64(base64String) {
    const bytes = Uint8Array.from(atob(base64String), c => c.charCodeAt(0));
    return bytes.buffer;
  }

  // Encrypt a file for P2P transfer
  async encryptFile(file) {
    const fileBuffer = await file.arrayBuffer();
    const iv = window.crypto.getRandomValues(new Uint8Array(12));
    const key = await window.crypto.subtle.generateKey(
      { name: "AES-GCM", length: 256 },
      true,
      ["encrypt"]
    );

    const encrypted = await window.crypto.subtle.encrypt(
      { name: "AES-GCM", iv: iv },
      key,
      fileBuffer
    );

    const exportedKey = await window.crypto.subtle.exportKey("raw", key);

    return {
      encryptedData: encrypted,
      iv: iv,
      key: exportedKey,
      fileName: file.name,
      fileType: file.type,
      fileSize: file.size
    };
  }

  // Decrypt a received file
  async decryptFile(encryptedFileData, iv, key) {
    const importedKey = await window.crypto.subtle.importKey(
      "raw",
      key,
      { name: "AES-GCM", length: 256 },
      false,
      ["decrypt"]
    );

    const decrypted = await window.crypto.subtle.decrypt(
      { name: "AES-GCM", iv: new Uint8Array(iv) },
      importedKey,
      encryptedFileData
    );

    return new Blob([decrypted], { type: encryptedFileData.fileType || "application/octet-stream" });
  }

  // Generate a signature for message authentication
  async signMessage(conversationId, messageData) {
    const key = this.keyStore.get(conversationId);
    if (!key) return null;

    const encoder = new TextEncoder();
    const data = encoder.encode(JSON.stringify(messageData));
    const signature = await window.crypto.subtle.sign(
      {
        name: "HMAC",
        hash: "SHA-256"
      },
      key,
      data
    );

    return Array.from(new Uint8Array(signature))
      .map(b => b.toString(16).padStart(2, '0'))
      .join('');
  }

  // Verify a message signature
  async verifySignature(conversationId, messageData, signature) {
    const key = this.keyStore.get(conversationId);
    if (!key) return false;

    const encoder = new TextEncoder();
    const data = encoder.encode(JSON.stringify(messageData));
    const signatureBytes = Uint8Array.from(
      signature.match(/.{2}/g).map(byte => parseInt(byte, 16))
    );

    return await window.crypto.subtle.verify(
      {
        name: "HMAC",
        hash: "SHA-256"
      },
      key,
      signatureBytes,
      data
    );
  }
}

// Singleton instance
const crypto = new E2ECrypto();

export { crypto, E2ECrypto };
