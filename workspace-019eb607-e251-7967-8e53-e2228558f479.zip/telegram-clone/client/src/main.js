import { crypto as e2eCrypto } from './crypto.js';
import { offlineQueue } from './offlineQueue.js';
import { p2pFileTransfer } from './p2pTransfer.js';

// Application State
const state = {
  userId: null,
  username: null,
  ws: null,
  currentConversation: null,
  conversations: new Map(),
  messages: new Map(),
  groups: new Map(),
  isOnline: navigator.onLine,
  typingTimeout: null,
  reconnectAttempts: 0,
  maxReconnectAttempts: 5,
  selectedFile: null
};

// DOM Elements
const elements = {};

// Initialize the application
async function init() {
  cacheElements();
  await offlineQueue.init();
  
  // Check if user is already logged in
  const savedUser = localStorage.getItem('securechat_user');
  if (savedUser) {
    const user = JSON.parse(savedUser);
    await login(user.username, user.password, true);
  }
  
  setupEventListeners();
  setupP2PFileTransfer();
}

// Cache DOM elements
function cacheElements() {
  elements.authScreen = document.getElementById('auth-screen');
  elements.chatScreen = document.getElementById('chat-screen');
  elements.loginForm = document.getElementById('login-form');
  elements.registerForm = document.getElementById('register-form');
  elements.tabLogin = document.getElementById('tab-login');
  elements.tabRegister = document.getElementById('tab-register');
  elements.conversationsList = document.getElementById('conversations-list');
  elements.messagesContainer = document.getElementById('messages-container');
  elements.messageInput = document.getElementById('message-input');
  elements.btnSend = document.getElementById('btn-send');
  elements.btnBack = document.getElementById('btn-back');
  elements.btnNewGroup = document.getElementById('btn-new-group');
  elements.btnLogout = document.getElementById('btn-logout');
  elements.btnFileTransfer = document.getElementById('btn-file-transfer');
  elements.btnGroupInfo = document.getElementById('btn-group-info');
  elements.groupModal = document.getElementById('group-modal');
  elements.groupNameInput = document.getElementById('group-name-input');
  elements.memberList = document.getElementById('member-list');
  elements.btnCreateGroup = document.getElementById('btn-create-group');
  elements.btnCancelGroup = document.getElementById('btn-cancel-group');
  elements.groupInfoModal = document.getElementById('group-info-modal');
  elements.groupInfoTitle = document.getElementById('group-info-title');
  elements.groupMembersList = document.getElementById('group-members-list');
  elements.btnCloseGroupInfo = document.getElementById('btn-close-group-info');
  elements.fileModal = document.getElementById('file-modal');
  elements.fileDropArea = document.getElementById('file-drop-area');
  elements.fileInput = document.getElementById('file-input');
  elements.filePreview = document.getElementById('file-preview');
  elements.btnSendFile = document.getElementById('btn-send-file');
  elements.btnCancelFile = document.getElementById('btn-cancel-file');
  elements.transferProgress = document.getElementById('transfer-progress');
  elements.progressFill = document.getElementById('progress-fill');
  elements.progressText = document.getElementById('progress-text');
  elements.toast = document.getElementById('toast');
  elements.welcomeScreen = document.getElementById('welcome-screen');
  elements.activeChat = document.getElementById('active-chat');
  elements.chatName = document.getElementById('chat-name');
  elements.chatStatus = document.getElementById('chat-status');
  elements.chatAvatar = document.getElementById('chat-avatar');
  elements.userAvatar = document.getElementById('user-avatar');
  elements.usernameDisplay = document.getElementById('username-display');
  elements.searchInput = document.getElementById('search-input');
  elements.typingIndicator = document.getElementById('typing-indicator');
  elements.typingText = document.getElementById('typing-text');
  elements.sidebar = document.querySelector('.sidebar');
}

// Setup event listeners
function setupEventListeners() {
  elements.tabLogin.addEventListener('click', () => switchTab('login'));
  elements.tabRegister.addEventListener('click', () => switchTab('register'));
  elements.loginForm.addEventListener('submit', handleLogin);
  elements.registerForm.addEventListener('submit', handleRegister);
  elements.btnSend.addEventListener('click', sendMessage);
  elements.messageInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') sendMessage();
  });
  elements.messageInput.addEventListener('input', handleTyping);
  elements.btnBack.addEventListener('click', () => showSidebar());
  elements.btnNewGroup.addEventListener('click', () => showGroupModal());
  elements.btnLogout.addEventListener('click', logout);
  elements.btnFileTransfer.addEventListener('click', () => showFileModal());
  elements.btnGroupInfo.addEventListener('click', () => showGroupInfoModal());
  elements.btnCreateGroup.addEventListener('click', createGroup);
  elements.btnCancelGroup.addEventListener('click', () => hideGroupModal());
  elements.btnCloseGroupInfo.addEventListener('click', () => hideGroupInfoModal());
  elements.fileDropArea.addEventListener('click', () => elements.fileInput.click());
  elements.fileDropArea.addEventListener('dragover', (e) => {
    e.preventDefault();
    elements.fileDropArea.style.borderColor = 'var(--primary)';
  });
  elements.fileDropArea.addEventListener('dragleave', () => {
    elements.fileDropArea.style.borderColor = 'var(--gray-light)';
  });
  elements.fileDropArea.addEventListener('drop', handleFileDrop);
  elements.fileInput.addEventListener('change', handleFileSelect);
  elements.btnSendFile.addEventListener('click', sendFile);
  elements.btnCancelFile.addEventListener('click', () => hideFileModal());
  elements.searchInput.addEventListener('input', handleSearch);
  window.addEventListener('online', handleOnline);
  window.addEventListener('offline', handleOffline);
}

// Setup P2P file transfer callbacks
function setupP2PFileTransfer() {
  p2pFileTransfer.onProgress = (progress, fileInfo) => {
    elements.progressFill.style.width = `${progress}%`;
    elements.progressText.textContent = `${Math.round(progress)}%`;
  };

  p2pFileTransfer.onComplete = (blob, fileInfo) => {
    elements.transferProgress.classList.add('hidden');
    showToast('File received successfully!');
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileInfo.fileName;
    a.click();
    URL.revokeObjectURL(url);
  };

  p2pFileTransfer.onError = (error) => {
    elements.transferProgress.classList.add('hidden');
    showToast(`File transfer error: ${error.message}`);
  };
}

// Tab switching
function switchTab(tab) {
  if (tab === 'login') {
    elements.tabLogin.classList.add('active');
    elements.tabRegister.classList.remove('active');
    elements.loginForm.classList.add('active');
    elements.registerForm.classList.remove('active');
  } else {
    elements.tabRegister.classList.add('active');
    elements.tabLogin.classList.remove('active');
    elements.registerForm.classList.add('active');
    elements.loginForm.classList.remove('active');
  }
}

// Handle login
async function handleLogin(e) {
  e.preventDefault();
  const username = document.getElementById('login-username').value.trim();
  const password = document.getElementById('login-password').value;
  if (username && password) {
    await login(username, password);
  }
}

// Login function
async function login(username, password, isAutoLogin = false) {
  try {
    const response = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    });
    
    if (!response.ok) {
      const err = await response.json();
      throw new Error(err.error || 'Login failed');
    }
    
    const data = await response.json();
    state.userId = data.userId;
    state.username = data.username;
    
    localStorage.setItem('securechat_user', JSON.stringify({
      username,
      password,
      userId: data.userId
    }));
    
    await e2eCrypto.generateIdentityKeys(data.userId);
    connectWebSocket();
    showChatScreen();
    
    if (!isAutoLogin) {
      showToast('Logged in successfully!');
    }
  } catch (error) {
    showToast(error.message || 'Login failed');
  }
}

// Handle registration
async function handleRegister(e) {
  e.preventDefault();
  const username = document.getElementById('register-username').value.trim();
  const password = document.getElementById('register-password').value;
  
  if (username && password) {
    try {
      const response = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
      });
      
      if (!response.ok) {
        const err = await response.json();
        throw new Error(err.error || 'Registration failed');
      }
      
      showToast('Account created! Please login.');
      switchTab('login');
      elements.registerForm.reset();
    } catch (error) {
      showToast(error.message || 'Registration failed');
    }
  }
}

// Connect to WebSocket
function connectWebSocket() {
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  const wsUrl = `${protocol}//${window.location.host}`;
  
  state.ws = new WebSocket(wsUrl);
  
  state.ws.onopen = () => {
    console.log('WebSocket connected');
    state.reconnectAttempts = 0;
    state.isOnline = true;
    
    state.ws.send(JSON.stringify({
      type: 'auth',
      userId: state.userId
    }));
    
    state.ws.send(JSON.stringify({
      type: 'presence',
      status: 'online'
    }));
    
    processOfflineQueue();
  };
  
  state.ws.onmessage = handleMessage;
  
  state.ws.onclose = () => {
    console.log('WebSocket disconnected');
    state.isOnline = false;
    
    if (state.reconnectAttempts < state.maxReconnectAttempts) {
      state.reconnectAttempts++;
      setTimeout(connectWebSocket, 1000 * state.reconnectAttempts);
    }
  };
  
  state.ws.onerror = (error) => {
    console.error('WebSocket error:', error);
  };
}

// Handle WebSocket messages
function handleMessage(event) {
  try {
    const data = JSON.parse(event.data);
    
    switch (data.type) {
      case 'auth_success':
        console.log('Authenticated with server');
        break;
      case 'message':
        handleIncomingMessage(data);
        break;
      case 'message_ack':
        handleAckMessage(data.messageId);
        break;
      case 'p2p_signal':
        handleP2PSignal(data);
        break;
      case 'typing':
        handleTypingIndicator(data.senderId, data.isTyping);
        break;
      case 'presence':
        handlePresenceUpdate(data.userId, data.status);
        break;
    }
  } catch (error) {
    console.error('Error handling message:', error);
  }
}

// Handle incoming messages
async function handleIncomingMessage(data) {
  const { messageId, senderId, conversationId, encryptedPayload, isGroup, messageType, timestamp } = data;
  
  try {
    const encryptedBytes = Uint8Array.from(atob(encryptedPayload), c => c.charCodeAt(0));
    const decryptedMessage = await e2eCrypto.decryptMessage(conversationId, encryptedBytes);
    
    const message = {
      id: messageId,
      senderId: senderId,
      conversationId: conversationId,
      content: decryptedMessage,
      timestamp: timestamp,
      isGroup: isGroup,
      messageType: messageType,
      status: 'received'
    };
    
    if (!state.messages.has(conversationId)) {
      state.messages.set(conversationId, []);
    }
    state.messages.get(conversationId).push(message);
    
    updateConversation(conversationId, message);
    
    if (state.currentConversation === conversationId) {
      displayMessage(message);
      scrollToBottom();
    }
  } catch (error) {
    console.error('Error decrypting message:', error);
    showToast('Failed to decrypt message');
  }
}

// Handle message acknowledgements
function handleAckMessage(messageId) {
  for (const [convId, messages] of state.messages) {
    const message = messages.find(m => m.id === messageId);
    if (message) {
      message.status = 'delivered';
      updateMessageStatus(messageId, 'delivered');
      break;
    }
  }
}

// Handle P2P signaling
function handleP2PSignal(data) {
  if (data.signal.type === 'offer') {
    p2pFileTransfer.acceptConnection(
      data.senderId,
      data.conversationId,
      data.signal.offer,
      (signal) => {
        if (state.ws && state.ws.readyState === WebSocket.OPEN) {
          state.ws.send(JSON.stringify({
            type: 'p2p_signal',
            senderId: state.userId,
            recipientId: data.senderId,
            signal: signal,
            conversationId: data.conversationId
          }));
        }
      }
    );
  } else if (data.signal.type === 'answer') {
    p2pFileTransfer.handleRemoteAnswer(data.senderId, data.signal.answer);
  } else if (data.signal.type === 'ice_candidate') {
    p2pFileTransfer.handleIceCandidate(data.senderId, data.signal.candidate);
  }
}

// Handle typing indicator
function handleTypingIndicator(senderId, isTyping) {
  if (state.currentConversation) {
    const senderName = getUserName(senderId);
    if (isTyping) {
      elements.typingText.textContent = `${senderName} is typing...`;
      elements.typingIndicator.classList.remove('hidden');
    } else {
      elements.typingIndicator.classList.add('hidden');
    }
  }
}

// Handle presence updates
function handlePresenceUpdate(userId, status) {
  const conversationId = e2eCrypto.generateConversationId(state.userId, userId);
  const conv = state.conversations.get(conversationId);
  if (conv) {
    conv.status = status;
    if (state.currentConversation === conversationId) {
      elements.chatStatus.textContent = status;
    }
  }
}

// Send message
async function sendMessage() {
  const content = elements.messageInput.value.trim();
  if (!content || !state.currentConversation) return;
  
  elements.messageInput.value = '';
  
  try {
    const encryptedData = await e2eCrypto.encryptMessage(state.currentConversation, content);
    const encryptedPayload = btoa(String.fromCharCode(...encryptedData));
    
    const messageId = Date.now().toString();
    const timestamp = new Date().toISOString();
    const conv = state.conversations.get(state.currentConversation);
    const isGroup = conv?.isGroup || false;
    
    const message = {
      id: messageId,
      senderId: state.userId,
      conversationId: state.currentConversation,
      content: content,
      encryptedPayload: encryptedPayload,
      timestamp: timestamp,
      isGroup: isGroup,
      messageType: 'text',
      status: 'pending'
    };
    
    if (!state.messages.has(state.currentConversation)) {
      state.messages.set(state.currentConversation, []);
    }
    state.messages.get(state.currentConversation).push(message);
    
    displayMessage(message);
    scrollToBottom();
    updateConversation(state.currentConversation, message);
    
    if (state.isOnline && state.ws && state.ws.readyState === WebSocket.OPEN) {
      state.ws.send(JSON.stringify({
        type: 'message',
        messageId: message.id,
        senderId: message.senderId,
        conversationId: message.conversationId,
        encryptedPayload: message.encryptedPayload,
        isGroup: message.isGroup,
        messageType: message.messageType,
        timestamp: message.timestamp,
        recipientId: getRecipientId(state.currentConversation),
        groupId: isGroup ? state.currentConversation : undefined
      }));
    } else {
      await offlineQueue.enqueue(message);
      showToast('Message queued - will send when online');
    }
  } catch (error) {
    console.error('Error sending message:', error);
    showToast('Failed to send message');
  }
}

// Handle typing
function handleTyping() {
  if (state.typingTimeout) {
    clearTimeout(state.typingTimeout);
  }
  
  if (state.ws && state.ws.readyState === WebSocket.OPEN && state.currentConversation) {
    state.ws.send(JSON.stringify({
      type: 'typing',
      senderId: state.userId,
      recipientId: getRecipientId(state.currentConversation),
      isTyping: true
    }));
  }
  
  state.typingTimeout = setTimeout(() => {
    if (state.ws && state.ws.readyState === WebSocket.OPEN && state.currentConversation) {
      state.ws.send(JSON.stringify({
        type: 'typing',
        senderId: state.userId,
        recipientId: getRecipientId(state.currentConversation),
        isTyping: false
      }));
    }
  }, 2000);
}

// Process offline queue
async function processOfflineQueue() {
  const queuedMessages = await offlineQueue.dequeueAll();
  
  for (const message of queuedMessages) {
    if (state.ws && state.ws.readyState === WebSocket.OPEN) {
      state.ws.send(JSON.stringify({
        type: 'message',
        messageId: message.id,
        senderId: message.senderId,
        conversationId: message.conversationId,
        encryptedPayload: message.encryptedPayload,
        isGroup: message.isGroup,
        messageType: message.messageType,
        timestamp: message.timestamp,
        recipientId: getRecipientId(message.conversationId),
        groupId: message.isGroup ? message.conversationId : undefined
      }));
      
      await offlineQueue.markSent(message.id);
    }
  }
  
  await offlineQueue.clearQueue();
}

// Get recipient ID from conversation ID
function getRecipientId(conversationId) {
  const conv = state.conversations.get(conversationId);
  if (conv && conv.isGroup) {
    return conv.groupId || conversationId;
  }
  
  const parts = conversationId.split('-');
  return parts.find(id => id !== state.userId);
}

// Get user name
function getUserName(userId) {
  return `User ${userId.slice(0, 8)}`;
}

// Display message in chat
function displayMessage(message) {
  const messageEl = document.createElement('div');
  messageEl.className = `message ${message.senderId === state.userId ? 'sent' : 'received'}`;
  messageEl.dataset.messageId = message.id;
  
  const time = new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  
  if (message.messageType === 'file') {
    messageEl.innerHTML = `
      <div class="file-message">
        <div class="file-icon">
          <svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor">
            <path d="M16.5 6v11.5c0 2.21-1.79 4-4 4s-4-1.79-4-4V5c0-1.38 1.12-2.5 2.5-2.5s2.5 1.12 2.5 2.5v10.5c0 .55-.45 1-1 1s-1-.45-1-1V6H10v9.5c0 1.38 1.12 2.5 2.5 2.5s2.5-1.12 2.5-2.5V5c0-2.21-1.79-4-4-4S7 2.79 7 5v12.5c0 3.04 2.46 5.5 5.5 5.5s5.5-2.46 5.5-5.5V6h-1.5z"/>
          </svg>
        </div>
        <div class="file-info">
          <div class="file-name">${message.fileName}</div>
          <div class="file-size">${formatFileSize(message.fileSize)}</div>
        </div>
      </div>
      <div class="message-meta">
        <span class="message-time">${time}</span>
        <span class="message-status ${message.status}">${getMessageStatusIcon(message.status)}</span>
      </div>
    `;
  } else {
    messageEl.innerHTML = `
      <div class="message-content">${message.content}</div>
      <div class="message-meta">
        <span class="message-time">${time}</span>
        <span class="message-status ${message.status}">${getMessageStatusIcon(message.status)}</span>
      </div>
    `;
  }
  
  elements.messagesContainer.appendChild(messageEl);
}

// Update message status in UI
function updateMessageStatus(messageId, status) {
  const messageEl = elements.messagesContainer.querySelector(`[data-message-id="${messageId}"]`);
  if (messageEl) {
    const statusEl = messageEl.querySelector('.message-status');
    if (statusEl) {
      statusEl.className = `message-status ${status}`;
      statusEl.innerHTML = getMessageStatusIcon(status);
    }
  }
}

// Get message status icon
function getMessageStatusIcon(status) {
  switch (status) {
    case 'pending':
      return '<svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg>';
    case 'sent':
      return '<svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>';
    case 'delivered':
      return '<svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M18 7l-1.41-1.41-6.34 6.34 1.41 1.41L18 7zm4.24-1.41L11.66 16.17 7.48 12l-1.41 1.41L11.66 19l12-12-1.42-1.41zM.41 13.41L6 19l1.41-1.41L1.83 12 .41 13.41z"/></svg>';
    default:
      return '';
  }
}

// Format file size
function formatFileSize(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  return `${(bytes / (1024 * 1024 * 1024)).toFixed(1)} GB`;
}

// Update conversation list
function updateConversation(conversationId, message) {
  if (!state.conversations.has(conversationId)) {
    state.conversations.set(conversationId, {
      id: conversationId,
      name: getConversationName(conversationId),
      isGroup: message.isGroup,
      lastMessage: message.content,
      lastMessageTime: message.timestamp,
      unread: 0,
      status: 'offline'
    });
  } else {
    const conv = state.conversations.get(conversationId);
    conv.lastMessage = message.content;
    conv.lastMessageTime = message.timestamp;
    
    if (conversationId !== state.currentConversation) {
      conv.unread++;
    }
  }
  
  renderConversations();
}

// Get conversation name
function getConversationName(conversationId) {
  const conv = state.conversations.get(conversationId);
  return conv?.name || `User ${conversationId.slice(0, 8)}`;
}

// Render conversations list
function renderConversations() {
  elements.conversationsList.innerHTML = '';
  
  const sortedConversations = Array.from(state.conversations.values())
    .sort((a, b) => new Date(b.lastMessageTime) - new Date(a.lastMessageTime));
  
  for (const conv of sortedConversations) {
    const convEl = document.createElement('div');
    convEl.className = `conversation-item ${conv.id === state.currentConversation ? 'active' : ''}`;
    convEl.dataset.conversationId = conv.id;
    
    const time = new Date(conv.lastMessageTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const preview = conv.lastMessage?.slice(0, 30) + (conv.lastMessage?.length > 30 ? '...' : '');
    
    convEl.innerHTML = `
      <div class="avatar">${conv.name.charAt(0).toUpperCase()}</div>
      <div class="conversation-info">
        <div class="conversation-name">${conv.name}</div>
        <div class="conversation-preview">${preview}</div>
      </div>
      <div class="conversation-meta">
        <div class="conversation-time">${time}</div>
        ${conv.unread > 0 ? `<div class="unread-badge">${conv.unread}</div>` : ''}
      </div>
    `;
    
    convEl.addEventListener('click', () => openConversation(conv.id));
    elements.conversationsList.appendChild(convEl);
  }
}

// Open conversation
async function openConversation(conversationId) {
  state.currentConversation = conversationId;
  
  document.querySelectorAll('.conversation-item').forEach(el => {
    el.classList.toggle('active', el.dataset.conversationId === conversationId);
  });
  
  const conv = state.conversations.get(conversationId);
  if (conv) {
    conv.unread = 0;
    renderConversations();
  }
  
  elements.welcomeScreen.classList.add('hidden');
  elements.activeChat.classList.remove('hidden');
  
  await loadMessages(conversationId);
  
  elements.chatName.textContent = conv?.name || 'Conversation';
  elements.chatStatus.textContent = conv?.status || 'offline';
  elements.chatAvatar.textContent = conv?.name?.charAt(0).toUpperCase() || '?';
  elements.btnGroupInfo.classList.toggle('hidden', !conv?.isGroup);
  
  if (window.innerWidth <= 768) {
    elements.sidebar.classList.add('hidden');
  }
}

// Load messages for a conversation
async function loadMessages(conversationId) {
  elements.messagesContainer.innerHTML = '';
  
  const messages = state.messages.get(conversationId) || [];
  
  for (const message of messages) {
    displayMessage(message);
  }
  
  if (messages.length === 0) {
    try {
      const response = await fetch(`/api/messages/${conversationId}`);
      if (response.ok) {
        const serverMessages = await response.json();
        
        for (const msg of serverMessages) {
          try {
            const encryptedBytes = Uint8Array.from(atob(msg.encryptedPayload), c => c.charCodeAt(0));
            const decryptedContent = await e2eCrypto.decryptMessage(conversationId, encryptedBytes);
            
            const message = {
              id: msg.id,
              senderId: msg.senderId,
              conversationId: msg.conversationId,
              content: decryptedContent,
              timestamp: msg.timestamp,
              isGroup: msg.isGroup,
              messageType: msg.messageType,
              status: 'received'
            };
            
            if (!state.messages.has(conversationId)) {
              state.messages.set(conversationId, []);
            }
            state.messages.get(conversationId).push(message);
            displayMessage(message);
          } catch (error) {
            console.error('Error decrypting message:', error);
          }
        }
      }
    } catch (error) {
      console.error('Error loading messages:', error);
    }
  }
  
  scrollToBottom();
}

// Show sidebar
function showSidebar() {
  if (elements.sidebar) {
    elements.sidebar.classList.remove('hidden');
  }
  state.currentConversation = null;
  
  document.querySelectorAll('.conversation-item').forEach(el => {
    el.classList.remove('active');
  });
  
  elements.welcomeScreen.classList.remove('hidden');
  elements.activeChat.classList.add('hidden');
}

// Show chat screen
function showChatScreen() {
  elements.authScreen.classList.add('hidden');
  elements.chatScreen.classList.remove('hidden');
  
  elements.userAvatar.textContent = state.username?.charAt(0).toUpperCase() || '?';
  elements.usernameDisplay.textContent = state.username;
  
  loadConversations();
}

// Load conversations
async function loadConversations() {
  try {
    const response = await fetch(`/api/conversations/${state.userId}`);
    if (response.ok) {
      const conversations = await response.json();
      
      for (const conv of conversations) {
        state.conversations.set(conv.conversationId, {
          id: conv.conversationId,
          name: conv.isGroup ? 'Group Chat' : `User ${conv.conversationId.slice(0, 8)}`,
          isGroup: conv.isGroup,
          lastMessage: conv.lastPayload ? 'Encrypted message' : '',
          lastMessageTime: conv.lastMessage || new Date().toISOString(),
          unread: 0,
          status: 'offline'
        });
      }
      
      renderConversations();
    }
  } catch (error) {
    console.error('Error loading conversations:', error);
  }
}

// Show group modal
function showGroupModal() {
  elements.groupModal.classList.remove('hidden');
  loadMemberList();
}

// Hide group modal
function hideGroupModal() {
  elements.groupModal.classList.add('hidden');
  elements.groupNameInput.value = '';
  elements.memberList.innerHTML = '';
}

// Load member list
async function loadMemberList() {
  elements.memberList.innerHTML = '';
  
  try {
    const response = await fetch('/api/users');
    if (response.ok) {
      const users = await response.json();
      
      for (const user of users) {
        if (user.userId !== state.userId) {
          const memberEl = document.createElement('div');
          memberEl.className = 'member-item';
          memberEl.innerHTML = `
            <input type="checkbox" id="member-${user.userId}" value="${user.userId}">
            <label for="member-${user.userId}">${user.username}</label>
          `;
          elements.memberList.appendChild(memberEl);
        }
      }
    }
  } catch (error) {
    console.error('Error loading users:', error);
  }
}

// Create group
async function createGroup() {
  const groupName = elements.groupNameInput.value.trim();
  const selectedMembers = Array.from(elements.memberList.querySelectorAll('input:checked'))
    .map(cb => cb.value);
  
  if (!groupName) {
    showToast('Please enter a group name');
    return;
  }
  
  try {
    const response = await fetch('/api/groups', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: groupName,
        createdBy: state.userId,
        memberIds: selectedMembers
      })
    });
    
    if (response.ok) {
      const group = await response.json();
      state.groups.set(group.groupId, group);
      
      showToast(`Group "${groupName}" created!`);
      hideGroupModal();
      
      state.conversations.set(group.groupId, {
        id: group.groupId,
        name: groupName,
        isGroup: true,
        lastMessage: '',
        lastMessageTime: new Date().toISOString(),
        unread: 0,
        status: 'online'
      });
      
      renderConversations();
    } else {
      throw new Error('Failed to create group');
    }
  } catch (error) {
    showToast(error.message || 'Failed to create group');
  }
}

// Show group info modal
function showGroupInfoModal() {
  if (!state.currentConversation) return;
  
  const conv = state.conversations.get(state.currentConversation);
  if (!conv || !conv.isGroup) return;
  
  elements.groupInfoModal.classList.remove('hidden');
  elements.groupInfoTitle.textContent = conv.name;
  loadGroupMembers(conv.id);
}

// Hide group info modal
function hideGroupInfoModal() {
  elements.groupInfoModal.classList.add('hidden');
}

// Load group members
async function loadGroupMembers(groupId) {
  elements.groupMembersList.innerHTML = '';
  
  try {
    const response = await fetch(`/api/groups/${groupId}/members`);
    if (response.ok) {
      const members = await response.json();
      
      for (const member of members) {
        const memberEl = document.createElement('div');
        memberEl.className = 'member-item';
        memberEl.innerHTML = `
          <div class="avatar">${member.username.charAt(0).toUpperCase()}</div>
          <div class="member-info">
            <div class="member-name">${member.username}</div>
            <div class="member-status">${member.status || 'offline'}</div>
          </div>
        `;
        elements.groupMembersList.appendChild(memberEl);
      }
    }
  } catch (error) {
    console.error('Error loading group members:', error);
  }
}

// Show file modal
function showFileModal() {
  elements.fileModal.classList.remove('hidden');
  elements.filePreview.classList.add('hidden');
  elements.transferProgress.classList.add('hidden');
}

// Hide file modal
function hideFileModal() {
  elements.fileModal.classList.add('hidden');
  elements.filePreview.classList.add('hidden');
  elements.transferProgress.classList.add('hidden');
  elements.fileInput.value = '';
  state.selectedFile = null;
}

// Handle file drop
function handleFileDrop(e) {
  e.preventDefault();
  elements.fileDropArea.style.borderColor = 'var(--gray-light)';
  
  if (e.dataTransfer.files.length > 0) {
    handleFile(e.dataTransfer.files[0]);
  }
}

// Handle file select
function handleFileSelect(e) {
  if (e.target.files.length > 0) {
    handleFile(e.target.files[0]);
  }
}

// Handle file
function handleFile(file) {
  elements.filePreview.classList.remove('hidden');
  elements.filePreview.innerHTML = `
    <div class="file-message">
      <div class="file-icon">
        <svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor">
          <path d="M16.5 6v11.5c0 2.21-1.79 4-4 4s-4-1.79-4-4V5c0-1.38 1.12-2.5 2.5-2.5s2.5 1.12 2.5 2.5v10.5c0 .55-.45 1-1 1s-1-.45-1-1V6H10v9.5c0 1.38 1.12 2.5 2.5 2.5s2.5-1.12 2.5-2.5V5c0-2.21-1.79-4-4-4S7 2.79 7 5v12.5c0 3.04 2.46 5.5 5.5 5.5s5.5-2.46 5.5-5.5V6h-1.5z"/>
        </svg>
      </div>
      <div class="file-info">
        <div class="file-name">${file.name}</div>
        <div class="file-size">${formatFileSize(file.size)}</div>
      </div>
    </div>
  `;
  
  state.selectedFile = file;
}

// Send file
async function sendFile() {
  if (!state.selectedFile || !state.currentConversation) {
    showToast('No file selected or no active conversation');
    return;
  }
  
  const recipientId = getRecipientId(state.currentConversation);
  
  try {
    elements.transferProgress.classList.remove('hidden');
    elements.progressFill.style.width = '0%';
    elements.progressText.textContent = '0%';
    
    if (!p2pFileTransfer.isConnected(recipientId)) {
      await p2pFileTransfer.initiateConnection(
        recipientId,
        state.currentConversation,
        (signal) => {
          if (state.ws && state.ws.readyState === WebSocket.OPEN) {
            state.ws.send(JSON.stringify({
              type: 'p2p_signal',
              senderId: state.userId,
              recipientId: recipientId,
              signal: signal,
              conversationId: state.currentConversation
            }));
          }
        }
      );
    }
    
    await p2pFileTransfer.sendFile(recipientId, state.selectedFile, state.currentConversation);
    
    const message = {
      id: Date.now().toString(),
      senderId: state.userId,
      conversationId: state.currentConversation,
      messageType: 'file',
      fileName: state.selectedFile.name,
      fileSize: state.selectedFile.size,
      timestamp: new Date().toISOString(),
      status: 'sent'
    };
    
    if (!state.messages.has(state.currentConversation)) {
      state.messages.set(state.currentConversation, []);
    }
    state.messages.get(state.currentConversation).push(message);
    
    displayMessage(message);
    scrollToBottom();
    
    hideFileModal();
    showToast('File sent successfully!');
  } catch (error) {
    console.error('Error sending file:', error);
    showToast(`Failed to send file: ${error.message}`);
  }
}

// Handle search
function handleSearch(e) {
  const query = e.target.value.toLowerCase();
  
  document.querySelectorAll('.conversation-item').forEach(el => {
    const name = el.querySelector('.conversation-name').textContent.toLowerCase();
    el.style.display = name.includes(query) ? 'flex' : 'none';
  });
}

// Handle online
function handleOnline() {
  state.isOnline = true;
  showToast('Back online!');
  
  if (!state.ws || state.ws.readyState !== WebSocket.OPEN) {
    connectWebSocket();
  }
  
  processOfflineQueue();
}

// Handle offline
function handleOffline() {
  state.isOnline = false;
  showToast('You are offline. Messages will be queued.');
}

// Logout
function logout() {
  if (state.ws) {
    state.ws.close();
  }
  
  state.userId = null;
  state.username = null;
  state.currentConversation = null;
  state.conversations.clear();
  state.messages.clear();
  
  localStorage.removeItem('securechat_user');
  
  elements.authScreen.classList.remove('hidden');
  elements.chatScreen.classList.add('hidden');
  
  showToast('Logged out successfully');
}

// Show toast notification
function showToast(message) {
  elements.toast.textContent = message;
  elements.toast.classList.add('show');
  elements.toast.classList.remove('hidden');
  
  setTimeout(() => {
    elements.toast.classList.remove('show');
    setTimeout(() => {
      elements.toast.classList.add('hidden');
    }, 300);
  }, 3000);
}

// Scroll to bottom of messages
function scrollToBottom() {
  setTimeout(() => {
    elements.messagesContainer.scrollTop = elements.messagesContainer.scrollHeight;
  }, 100);
}

// Initialize app
init();
