// Offline Message Queue
// Stores messages locally when user is offline and syncs when connection is restored

class OfflineQueue {
  constructor() {
    this.queue = [];
    this.dbName = 'OfflineMessageQueue';
    this.storeName = 'messages';
    this.db = null;
  }

  // Initialize IndexedDB
  async init() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(this.dbName, 1);

      request.onerror = () => reject(request.error);
      request.onsuccess = () => {
        this.db = request.result;
        resolve();
      };

      request.onupgradeneeded = (event) => {
        const db = event.target.result;
        if (!db.objectStoreNames.contains(this.storeName)) {
          db.createObjectStore(this.storeName, { keyPath: 'id' });
        }
      };
    });
  }

  // Add message to queue
  async enqueue(message) {
    if (!this.db) await this.init();

    const transaction = this.db.transaction([this.storeName], 'readwrite');
    const store = transaction.objectStore(this.storeName);
    store.add({
      ...message,
      status: 'pending',
      queuedAt: Date.now()
    });

    this.queue.push(message);
    return message;
  }

  // Get all queued messages
  async dequeueAll() {
    if (!this.db) await this.init();

    return new Promise((resolve, reject) => {
      const transaction = this.db.transaction([this.storeName], 'readonly');
      const store = transaction.objectStore(this.storeName);
      const request = store.getAll();

      request.onsuccess = () => {
        const messages = request.result;
        resolve(messages);
      };

      request.onerror = () => reject(request.error);
    });
  }

  // Mark message as sent
  async markSent(messageId) {
    if (!this.db) await this.init();

    const transaction = this.db.transaction([this.storeName], 'readwrite');
    const store = transaction.objectStore(this.storeName);
    const request = store.get(messageId);

    request.onsuccess = () => {
      const message = request.result;
      if (message) {
        message.status = 'sent';
        store.put(message);
      }
    };
  }

  // Clear queue after successful sync
  async clearQueue() {
    if (!this.db) await this.init();

    const transaction = this.db.transaction([this.storeName], 'readwrite');
    const store = transaction.objectStore(this.storeName);
    store.clear();
    this.queue = [];
  }

  // Get queue size
  async size() {
    if (!this.db) await this.init();

    return new Promise((resolve, reject) => {
      const transaction = this.db.transaction([this.storeName], 'readonly');
      const store = transaction.objectStore(this.storeName);
      const request = store.count();

      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }
}

// Singleton instance
const offlineQueue = new OfflineQueue();

export { offlineQueue, OfflineQueue };
