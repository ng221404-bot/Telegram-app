// P2P File Transfer using WebRTC Data Channels
// Enables direct file transfers between users without server relay

class P2PFileTransfer {
  constructor() {
    this.connections = new Map(); // userId -> RTCPeerConnection
    this.dataChannels = new Map(); // userId -> RTCDataChannel
    this.pendingFiles = new Map(); // conversationId -> file info
    this.config = {
      iceServers: [
        { urls: 'stun:stun.l.google.com:19302' },
        { urls: 'stun:stun1.l.google.com:19302' }
      ]
    };
    this.onProgress = null;
    this.onComplete = null;
    this.onError = null;
  }

  // Initialize a P2P connection with a peer
  async initiateConnection(peerId, conversationId, signalCallback) {
    try {
      const pc = new RTCPeerConnection(this.config);
      this.connections.set(peerId, pc);

      // Create data channel for file transfer
      const dc = pc.createDataChannel(`fileTransfer-${conversationId}`, {
        ordered: true
      });

      this.setupDataChannel(dc, peerId, conversationId);
      this.dataChannels.set(peerId, dc);

      // Handle ICE candidates
      pc.onicecandidate = (event) => {
        if (event.candidate) {
          signalCallback({
            type: 'ice_candidate',
            candidate: event.candidate,
            peerId: peerId,
            conversationId: conversationId
          });
        }
      };

      // Create and send offer
      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);

      signalCallback({
        type: 'offer',
        offer: offer,
        peerId: peerId,
        conversationId: conversationId
      });

      return pc;
    } catch (error) {
      console.error('Error initiating P2P connection:', error);
      if (this.onError) this.onError(error);
      throw error;
    }
  }

  // Accept an incoming P2P connection
  async acceptConnection(peerId, conversationId, offer, signalCallback) {
    try {
      const pc = new RTCPeerConnection(this.config);
      this.connections.set(peerId, pc);

      // Handle incoming data channels
      pc.ondatachannel = (event) => {
        const dc = event.channel;
        this.setupDataChannel(dc, peerId, conversationId);
        this.dataChannels.set(peerId, dc);
      };

      // Handle ICE candidates
      pc.onicecandidate = (event) => {
        if (event.candidate) {
          signalCallback({
            type: 'ice_candidate',
            candidate: event.candidate,
            peerId: peerId,
            conversationId: conversationId
          });
        }
      };

      // Set remote description (offer)
      await pc.setRemoteDescription(new RTCSessionDescription(offer));

      // Create and send answer
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);

      signalCallback({
        type: 'answer',
        answer: answer,
        peerId: peerId,
        conversationId: conversationId
      });

      return pc;
    } catch (error) {
      console.error('Error accepting P2P connection:', error);
      if (this.onError) this.onError(error);
      throw error;
    }
  }

  // Handle ICE candidate from signaling
  async handleIceCandidate(peerId, candidate) {
    const pc = this.connections.get(peerId);
    if (pc) {
      try {
        await pc.addIceCandidate(new RTCIceCandidate(candidate));
      } catch (error) {
        console.error('Error adding ICE candidate:', error);
      }
    }
  }

  // Handle remote answer from signaling
  async handleRemoteAnswer(peerId, answer) {
    const pc = this.connections.get(peerId);
    if (pc) {
      try {
        await pc.setRemoteDescription(new RTCSessionDescription(answer));
      } catch (error) {
        console.error('Error setting remote answer:', error);
      }
    }
  }

  // Setup data channel event handlers
  setupDataChannel(dc, peerId, conversationId) {
    dc.binaryType = 'arraybuffer';

    dc.onopen = () => {
      console.log(`P2P connection opened with ${peerId}`);
    };

    dc.onclose = () => {
      console.log(`P2P connection closed with ${peerId}`);
      this.dataChannels.delete(peerId);
    };

    dc.onerror = (error) => {
      console.error(`P2P connection error with ${peerId}:`, error);
      if (this.onError) this.onError(error);
    };

    // Handle incoming file chunks
    dc.onmessage = async (event) => {
      if (typeof event.data === 'string') {
        // File metadata message
        const metadata = JSON.parse(event.data);
        this.pendingFiles.set(conversationId, metadata);
        return;
      }

      // Handle binary data (file chunks)
      const pendingFile = this.pendingFiles.get(conversationId);
      if (!pendingFile) return;

      pendingFile.receivedChunks = pendingFile.receivedChunks || [];
      pendingFile.receivedChunks.push(event.data);
      pendingFile.receivedBytes = (pendingFile.receivedBytes || 0) + event.data.byteLength;

      // Report progress
      if (this.onProgress) {
        const progress = (pendingFile.receivedBytes / pendingFile.totalSize) * 100;
        this.onProgress(progress, pendingFile);
      }

      // File transfer complete
      if (pendingFile.receivedBytes >= pendingFile.totalSize) {
        const blob = new Blob(pendingFile.receivedChunks, { type: pendingFile.fileType });
        this.pendingFiles.delete(conversationId);

        if (this.onComplete) {
          this.onComplete(blob, pendingFile);
        }
      }
    };
  }

  // Send a file through P2P connection
  async sendFile(peerId, file, conversationId) {
    const dc = this.dataChannels.get(peerId);
    if (!dc || dc.readyState !== 'open') {
      throw new Error('No active P2P connection for file transfer');
    }

    // Send file metadata first
    const metadata = {
      type: 'file',
      fileName: file.name,
      fileType: file.type,
      fileSize: file.size,
      conversationId: conversationId
    };

    dc.send(JSON.stringify(metadata));

    // Read and send file in chunks
    const CHUNK_SIZE = 16384; // 16KB chunks
    const arrayBuffer = await file.arrayBuffer();
    let offset = 0;
    let sentBytes = 0;

    return new Promise((resolve, reject) => {
      const sendChunk = () => {
        if (offset >= arrayBuffer.byteLength) {
          resolve();
          return;
        }

        const chunk = arrayBuffer.slice(offset, offset + CHUNK_SIZE);
        offset += CHUNK_SIZE;
        sentBytes += chunk.byteLength;

        if (dc.readyState === 'open') {
          dc.send(chunk);

          // Report progress
          if (this.onProgress) {
            const progress = (sentBytes / arrayBuffer.byteLength) * 100;
            this.onProgress(progress, { fileName: file.name, fileSize: file.size });
          }

          // Continue sending next chunk
          setTimeout(sendChunk, 0);
        } else {
          reject(new Error('P2P connection closed during transfer'));
        }
      };

      sendChunk();
    });
  }

  // Close a P2P connection
  closeConnection(peerId) {
    const pc = this.connections.get(peerId);
    const dc = this.dataChannels.get(peerId);

    if (dc) {
      dc.close();
      this.dataChannels.delete(peerId);
    }

    if (pc) {
      pc.close();
      this.connections.delete(peerId);
    }

    this.pendingFiles.delete(peerId);
  }

  // Check if connected to peer
  isConnected(peerId) {
    const dc = this.dataChannels.get(peerId);
    return dc && dc.readyState === 'open';
  }

  // Get connection state
  getConnectionState(peerId) {
    const pc = this.connections.get(peerId);
    if (!pc) return 'disconnected';
    return pc.connectionState || 'disconnected';
  }
}

// Singleton instance
const p2pFileTransfer = new P2PFileTransfer();

export { p2pFileTransfer, P2PFileTransfer };
