const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const { v4: uuidv4 } = require('uuid');
const Database = require('better-sqlite3');
const cors = require('cors');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.static(path.join(__dirname, '..', 'client', 'dist')));

// --- Database Setup ---
const db = new Database('messages.db');

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    userId TEXT PRIMARY KEY,
    username TEXT UNIQUE,
    passwordHash TEXT,
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS messages (
    id TEXT PRIMARY KEY,
    senderId TEXT,
    recipientId TEXT,
    conversationId TEXT,
    encryptedPayload TEXT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    isGroup INTEGER DEFAULT 0,
    messageType TEXT DEFAULT 'text'
  );

  CREATE TABLE IF NOT EXISTS groups (
    id TEXT PRIMARY KEY,
    name TEXT,
    createdBy TEXT,
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS group_members (
    groupId TEXT,
    userId TEXT,
    PRIMARY KEY (groupId, userId)
  );

  CREATE TABLE IF NOT EXISTS offline_queue (
    id TEXT PRIMARY KEY,
    recipientId TEXT,
    payload TEXT,
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`);

// --- WebSocket Signaling Server ---
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

// Track connected users: userId -> Set of WebSocket connections
const connectedUsers = new Map();

// --- Auth Endpoints ---
app.post('/api/auth/register', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ error: 'Username and password required' });
  }

  const userId = uuidv4();
  const passwordHash = Buffer.from(password).toString('base64');

  try {
    const stmt = db.prepare('INSERT INTO users (userId, username, passwordHash) VALUES (?, ?, ?)');
    stmt.run(userId, username, passwordHash);
    res.json({ userId, username });
  } catch (err) {
    if (err.message.includes('UNIQUE constraint failed')) {
      res.status(409).json({ error: 'Username already exists' });
    } else {
      res.status(500).json({ error: 'Registration failed' });
    }
  }
});

app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body;
  const passwordHash = Buffer.from(password).toString('base64');

  const user = db.prepare('SELECT * FROM users WHERE username = ? AND passwordHash = ?')
    .get(username, passwordHash);

  if (user) {
    res.json({ userId: user.userId, username: user.username });
  } else {
    res.status(401).json({ error: 'Invalid credentials' });
  }
});

// --- Message Endpoints ---
app.get('/api/messages/:conversationId', (req, res) => {
  const { conversationId } = req.params;
  const messages = db.prepare(
    'SELECT * FROM messages WHERE conversationId = ? ORDER BY timestamp ASC'
  ).all(conversationId);
  res.json(messages);
});

app.get('/api/conversations/:userId', (req, res) => {
  const { userId } = req.params;
  const conversations = db.prepare(`
    SELECT DISTINCT conversationId, isGroup, MAX(timestamp) as lastMessage
    FROM messages
    WHERE senderId = ? OR recipientId = ? OR conversationId IN (
      SELECT groupId FROM group_members WHERE userId = ?
    )
    GROUP BY conversationId
    ORDER BY lastMessage DESC
  `).all(userId, userId, userId);
  res.json(conversations);
});

// --- Group Endpoints ---
app.post('/api/groups', (req, res) => {
  const { name, createdBy, memberIds } = req.body;
  const groupId = uuidv4();

  try {
    db.transaction(() => {
      db.prepare('INSERT INTO groups (id, name, createdBy) VALUES (?, ?, ?)')
        .run(groupId, name, createdBy);

      db.prepare('INSERT OR IGNORE INTO group_members (groupId, userId) VALUES (?, ?)')
        .run(groupId, createdBy);

      for (const memberId of (memberIds || [])) {
        db.prepare('INSERT OR IGNORE INTO group_members (groupId, userId) VALUES (?, ?)')
          .run(groupId, memberId);
      }
    })();
    res.json({ groupId, name, createdBy, memberIds });
  } catch (err) {
    res.status(500).json({ error: 'Failed to create group' });
  }
});

app.get('/api/groups/:userId', (req, res) => {
  const { userId } = req.params;
  const groups = db.prepare(`
    SELECT g.*, COUNT(gm.userId) as memberCount
    FROM groups g
    JOIN group_members gm ON g.id = gm.groupId
    WHERE gm.userId = ?
    GROUP BY g.id
  `).all(userId);
  res.json(groups);
});

app.get('/api/groups/:groupId/members', (req, res) => {
  const { groupId } = req.params;
  const members = db.prepare(`
    SELECT u.userId, u.username FROM users u
    JOIN group_members gm ON u.userId = gm.userId
    WHERE gm.groupId = ?
  `).all(groupId);
  res.json(members);
});

// --- User Endpoints ---
app.get('/api/users', (req, res) => {
  const users = db.prepare('SELECT userId, username FROM users').all();
  res.json(users);
});

app.get('/api/users/online', (req, res) => {
  const onlineUsers = Array.from(connectedUsers.keys()).map(userId => {
    return db.prepare('SELECT userId, username FROM users WHERE userId = ?').get(userId);
  }).filter(Boolean);
  res.json(onlineUsers);
});

// --- Offline Queue ---
app.get('/api/offline-queue/:userId', (req, res) => {
  const { userId } = req.params;
  const messages = db.prepare(
    'SELECT * FROM offline_queue WHERE recipientId = ? ORDER BY createdAt ASC'
  ).all(userId);

  db.prepare('DELETE FROM offline_queue WHERE recipientId = ?').run(userId);

  res.json(messages);
});

// --- WebSocket Handling ---
wss.on('connection', (ws, req) => {
  let userId = null;

  ws.on('message', (message) => {
    try {
      const data = JSON.parse(message);

      switch (data.type) {
        case 'auth':
          userId = data.userId;
          if (!connectedUsers.has(userId)) {
            connectedUsers.set(userId, new Set());
          }
          connectedUsers.get(userId).add(ws);
          ws.send(JSON.stringify({ type: 'auth_success', userId }));
          break;

        case 'message': {
          // Store message
          if (data.messageId && data.conversationId) {
            db.prepare(
              'INSERT OR IGNORE INTO messages (id, senderId, recipientId, conversationId, encryptedPayload, isGroup, messageType) VALUES (?, ?, ?, ?, ?, ?, ?)'
            ).run(
              data.messageId,
              data.senderId,
              data.recipientId || null,
              data.conversationId,
              data.encryptedPayload,
              data.isGroup || 0,
              data.messageType || 'text'
            );
          }

          // Deliver to recipient if online
          if (data.recipientId && connectedUsers.has(data.recipientId)) {
            const recipients = connectedUsers.get(data.recipientId);
            recipients.forEach(rWs => {
              if (rWs.readyState === WebSocket.OPEN) {
                rWs.send(JSON.stringify({
                  type: 'message',
                  messageId: data.messageId,
                  senderId: data.senderId,
                  conversationId: data.conversationId,
                  encryptedPayload: data.encryptedPayload,
                  isGroup: data.isGroup,
                  messageType: data.messageType,
                  timestamp: data.timestamp
                }));
              }
            });
          }

          // Queue offline messages
          if (data.recipientId && !connectedUsers.has(data.recipientId)) {
            db.prepare(
              'INSERT INTO offline_queue (id, recipientId, payload) VALUES (?, ?, ?)'
            ).run(uuidv4(), data.recipientId, JSON.stringify(data));
          }

          // Broadcast to group members
          if (data.isGroup && data.groupId) {
            const members = db.prepare(
              'SELECT userId FROM group_members WHERE groupId = ?'
            ).all(data.groupId);

            members.forEach(member => {
              if (member.userId !== data.senderId && connectedUsers.has(member.userId)) {
                const recipients = connectedUsers.get(member.userId);
                recipients.forEach(rWs => {
                  if (rWs.readyState === WebSocket.OPEN) {
                    rWs.send(JSON.stringify({
                      type: 'message',
                      messageId: data.messageId,
                      senderId: data.senderId,
                      conversationId: data.conversationId,
                      encryptedPayload: data.encryptedPayload,
                      isGroup: true,
                      groupId: data.groupId,
                      messageType: data.messageType,
                      timestamp: data.timestamp
                    }));
                  }
                });
              }
            });
          }

          // Acknowledge message storage
          ws.send(JSON.stringify({
            type: 'message_ack',
            messageId: data.messageId
          }));
          break;
        }

        case 'p2p_signal':
          if (data.recipientId && connectedUsers.has(data.recipientId)) {
            const recipients = connectedUsers.get(data.recipientId);
            recipients.forEach(rWs => {
              if (rWs.readyState === WebSocket.OPEN) {
                rWs.send(JSON.stringify({
                  type: 'p2p_signal',
                  senderId: data.senderId,
                  signal: data.signal,
                  conversationId: data.conversationId
                }));
              }
            });
          }
          break;

        case 'typing':
          if (data.recipientId && connectedUsers.has(data.recipientId)) {
            const recipients = connectedUsers.get(data.recipientId);
            recipients.forEach(rWs => {
              if (rWs.readyState === WebSocket.OPEN) {
                rWs.send(JSON.stringify({
                  type: 'typing',
                  senderId: data.senderId,
                  isTyping: data.isTyping
                }));
              }
            });
          }
          break;

        case 'presence':
          if (userId) {
            for (const [otherId, connections] of connectedUsers) {
              if (otherId !== userId) {
                connections.forEach(cWs => {
                  if (cWs.readyState === WebSocket.OPEN) {
                    cWs.send(JSON.stringify({
                      type: 'presence',
                      userId: userId,
                      status: data.status
                    }));
                  }
                });
              }
            }
          }
          break;
      }
    } catch (err) {
      console.error('WebSocket message error:', err);
    }
  });

  ws.on('close', () => {
    if (userId && connectedUsers.has(userId)) {
      connectedUsers.get(userId).delete(ws);
      if (connectedUsers.get(userId).size === 0) {
        connectedUsers.delete(userId);
      }
    }
  });
});

// Serve the client app
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'client', 'dist', 'index.html'));
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
